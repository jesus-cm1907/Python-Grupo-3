from django.db import models
from configuracion.models import configuracion

# Create your models here.

class chatPrivado(models.Model):
        id_usuario_var = models.ForeignKey(configuracion, on_delete=models.CASCADE)
        id_usuario2_var = models.CharField(max_length=128)
        mensaje_var = models.CharField(max_length=128)
        fotoperfil_var = models.ImageField(upload_to='imagen')
        fotoperfil2_var = models.ImageField(upload_to='imagen')