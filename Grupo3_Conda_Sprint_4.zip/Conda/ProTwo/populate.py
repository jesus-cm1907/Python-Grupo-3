import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ProTwo.settings")

import django
django.setup()

from AppTwo.models import Post
from configuracion.models import configuracion
from cabecera.models import Cabecera
from chatPrivado.models import chatPrivado
from informacion.models import informacion
from login.models import Login
from publicacion.models import publicacion
from registro.models import registro
from faker import Faker


fakegen = Faker()

def populate(N=5):  
    for entry in range(N):
        fake_index_var = fakegen.name().split()
        fake_first_name = fake_index_var[0]
        fake_last_name = fake_index_var[1]
        fake_email = fakegen.email()
        fake_id = fakegen.pyint()
        fake_web = fakegen.hostname()
        fake_telefono = fakegen.phone_number()
        fake_perfil = 'perfil'
        fake_sexo = 'Hombre'
        fake_historia = fakegen.image_url()
        fake_visualizaciones = fakegen.pyint()
        fake_id2 = fakegen.unique.pyint()
        fake_mensaje = fakegen.text(max_nb_chars=20)
        fake_fotoperfil = fakegen.image_url()
        fake_fotoperfil2 = fakegen.image_url()
        fake_imagenid = fakegen.image_url()
        fake_caption = fakegen.text(max_nb_chars=20)
        fake_descripcion = fakegen.text(max_nb_chars=50)
        fake_comment = fakegen.text(max_nb_chars=40)
        fake_likes = fakegen.pyint()
        fake_contraseña = fakegen.unique.pyint()


        Configuracion = configuracion.objects.get_or_create(nombre_var = fake_first_name, id_usuario_var = fake_id, web_var = fake_web, fotoperfil_var = fake_fotoperfil,  email_var = fake_email,telefono_var = fake_telefono, sexo_var = fake_sexo)[0]
        appTwo = Post.objects.get_or_create(index_var = fake_index_var, comment_var = fake_comment, id_usuario_var = configuracion, likes_var = fake_likes, caption_var = fake_caption, foto_post_var = fake_fotoperfil2)[0]
        cabecera = Cabecera.objects.get_or_create(id_usuario_var = fake_id, historia_var = fake_historia, visualizaciones_var = fake_visualizaciones)[0]
        chatPrivado = chatPrivado.objects.get_or_create(id_usuario_var = fake_id, id_usuario2_var = fake_id2, mensaje_var = fake_mensaje, fotoperfil2_var=fake_fotoperfil, fotoperfil_var = fake_fotoperfil2)[0]
        informacion = informacion.objects.get_or_create(id_usuario_var = fake_id, descripcion_var = fake_descripcion, fotoperfil_var = fake_fotoperfil )[0]
        login = Login.objects.get_or_create(id_usuario_var = fake_id, contraseña_var = fake_contraseña)[0]
        publicacion = publicacion.objects.get_or_create(id_usuario_var = fake_id, caption_var = fake_caption, imagenid_var = fake_imagenid, fotoperfil_var = fake_fotoperfil2)[0]
        registro = registro.objects.get_or_create(id_usuario_var = fake_id, contraseña_var = fake_contraseña)[0]



print("Rellenando base de datos")
populate(20)

print("COMPLETADO")