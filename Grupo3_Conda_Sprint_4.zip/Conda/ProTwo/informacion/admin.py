from django.contrib import admin
from informacion.models import informacion
# Register your models here.

admin.site.register(informacion)