from django.contrib import admin
from registro.models import registro
# Register your models here.

admin.site.register(registro)