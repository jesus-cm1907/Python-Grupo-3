from django.contrib import admin
from cabecera.models import Cabecera

# Register your models here.

admin.site.register(Cabecera)