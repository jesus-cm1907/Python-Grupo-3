from django.apps import AppConfig


class InformacionConfig(AppConfig):
    name = 'informacion'
