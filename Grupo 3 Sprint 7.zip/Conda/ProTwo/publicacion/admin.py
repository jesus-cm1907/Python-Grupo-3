from django.contrib import admin
from publicacion.models import publicacion

# Register your models here.

admin.site.register(publicacion)