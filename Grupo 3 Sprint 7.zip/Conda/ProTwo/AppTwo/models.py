from django.db import models
from configuracion.models import configuracion


# Create your models here.

class Post(models.Model):
        index_var = models.CharField(max_length=128, unique=True)
        comment_var = models.CharField(max_length=128)
        id_usuario_var = models.models.ForeignKey( on_delete=models.CASCADE)
        likes_var = models.CharField(max_length=128)
        caption_var = models.CharField(max_length=128)