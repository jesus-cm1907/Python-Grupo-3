from django.apps import AppConfig


class CabeceraConfig(AppConfig):
    name = 'cabecera'
