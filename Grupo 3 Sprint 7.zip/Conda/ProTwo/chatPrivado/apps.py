from django.apps import AppConfig


class ChatprivadoConfig(AppConfig):
    name = 'chatPrivado'
