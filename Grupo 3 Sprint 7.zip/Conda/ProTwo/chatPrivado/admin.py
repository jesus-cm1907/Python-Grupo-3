from django.contrib import admin
from chatPrivado.models import chatPrivado

# Register your models here.

admin.site.register(chatPrivado)