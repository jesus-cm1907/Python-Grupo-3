from django.contrib import admin
from configuracion.models import configuracion
# Register your models here.

admin.site.register(configuracion)